﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<Engine> engines = new List<Engine>();
            List<Car> cars = new List<Car>();

            for (int i = 0; i < n; i++)
            {
                Engine newEngine = new Engine();
                string[] inputEngine = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();

                string engineModel = inputEngine[0];
                int enginePower = int.Parse(inputEngine[1]);

                newEngine.Model = engineModel;
                newEngine.Power = enginePower;
                if (inputEngine.Length > 2)
                {

                   
                    bool successfullyParsed = int.TryParse(inputEngine[2], out int result);
                    if (successfullyParsed)
                    {
                        int engineDisplacement = result;
                        newEngine.Displacement = engineDisplacement;
                    }
                    else
                    {
                        string engineEfficiency = inputEngine[2];

                        newEngine.Efficiency = engineEfficiency;
                    }

                }
                if (inputEngine.Length > 3)
                {

                     
                   
                     string engineEfficiency = inputEngine[3];
                    newEngine.Efficiency = engineEfficiency;
                    
                }
                engines.Add(newEngine);
            }

            int m = int.Parse(Console.ReadLine());


            for (int i = 0; i < m; i++)
            {
                Car newCar = new Car();
                string[] inputCars = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).ToArray();

               

                    string inputModel = inputCars[0];
                    newCar.Model = inputModel;
                foreach (var item in engines)
                {
                    if (item.Model == inputCars[1])
                    {
                        newCar.Engine = item;
                    }
                }
                    

                if (inputCars.Length > 2)
                {
                   
                    bool isWeight = int.TryParse(inputCars[2], out int result);

                    if (isWeight)
                    {
                        int carWeight = result;
                        newCar.Weight = carWeight;
                    }
                    else
                    {
                        string carColour = inputCars[2];
                        newCar.Colour = carColour;
                    }
                }

                if (inputCars.Length > 3)
                {
                    string carColour = inputCars[3];
                    newCar.Colour = carColour;
                }


                cars.Add(newCar);
            }

            foreach (var carr in cars)
            {
                Console.WriteLine(carr);
            }

        }
    }
}
