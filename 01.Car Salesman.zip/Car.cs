﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generics
{
    public class Car
    {
        public string Model { get; set; }

        public Engine Engine { get; set; }
        public int? Weight { get; set; }
        public string Colour { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{Model}:");
            sb.AppendLine(Engine.ToString());
            sb.AppendLine($"Weight: {(Weight.HasValue ? Weight.ToString() : "n/a")}");
            sb.AppendLine($"Color: {Colour ?? "n/a"}");

            return sb.ToString().TrimEnd();
        }

    }
}
