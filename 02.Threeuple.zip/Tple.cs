﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generics
{
    public class MyTuple<Tump1, Tump2, Tump3>
    {
        public MyTuple(Tump1 right, Tump2 middle, Tump3 left)
        {
            Right = right;
            Middle = middle;
            Left = left;

        }

        public Tump1 Right { get; set; }
        public Tump2 Middle { get; set; }
        public Tump3 Left { get; set; }

        public string GetTipe()
        {
            return $"{Right} -> {Middle} -> {Left}";
        }

    }
}
