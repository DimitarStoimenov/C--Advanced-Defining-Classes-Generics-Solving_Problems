﻿using System;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            string[] nameTownInput = Console.ReadLine().Split();
            string name = $"{nameTownInput[0]} {nameTownInput[1]}";
            string street = nameTownInput[2];
            string town = nameTownInput[3];

            string[] nameBierInput = Console.ReadLine().Split();
            string nameB = nameBierInput[0];
            int ageB = int.Parse(nameBierInput[1]);
            bool condition = nameBierInput[2] == "drunk";

            string[] numbersInput = Console.ReadLine().Split();
            string numbOne = numbersInput[0];
            double doubleTwo = double.Parse(numbersInput[1]);
            string strThree = numbersInput[2];
            
            MyTuple<string, string, string> nameTown = new MyTuple<string, string, string>(name, street,town);
           
            MyTuple<string, int, bool> nameBier = new MyTuple<string, int, bool>(nameB, ageB, condition );
            MyTuple<string, double, string> intDouble = new MyTuple<string, double, string>(numbOne, doubleTwo, strThree);

            Console.WriteLine(nameTown.GetTipe());
            Console.WriteLine(nameBier.GetTipe());
            Console.WriteLine(intDouble.GetTipe());

        }
    }
}
